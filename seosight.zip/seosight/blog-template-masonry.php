<?php

/**
 * Template Name: Blog Masonry
 */

get_template_part( 'blog-template-grid' );
